## Maven Goodbye example

This example shows how you can migrate to Gradle fairly easy.
Note: some plugins might not be picked up one for one and some research maybe needed to find a replacement.

#### Setup

This uses a manually configured job in Jenkins to show the build using maven and then one related to gradle.
It can be manually configured with a web hook between Gitea and Jenkins using the web token trigger.
This demo excludes some steps that would require additional security.  Consult your administrator or security specialist on your specific needs.

- Web Hooks typically need access to Jenkins, this can be done via anonymous read access (not recommended, but okay for demos) or using a authorization header.
- Two jobs will be setup, one to monitor a maven branch and another to monitor the gradle branch.


#### Convert from maven to gradle

- first, make sure maven builds succesfully 
  `mvn clean install`
- next convert to gradle  
  `gradle init`  
- notice new files for gradle  
<table><tr><td>.gradle</td><td># gradle temp directory</td></tr><tr><td>gradle</td><td># gradle wrapper</td></tr><tr><td>gradlew</td><td># wrapper unix script</td></tr><tr><td>gradlew.bat</td><td># wrapper windows script</td></tr>  <tr><td>build.gradle[.kts]</td><td>build definition</td></tr>  <tr><td>settings.gradle[.kts]</td><td>project settings</td></tr>   <tr><td>build</td><td>output folder (like target)</td></tr></table>
- add missing plugin (spring boot)  
  plugins {  
     id 'java'  
     id 'maven'  
     id 'org.springframework.boot' version '2.1.1.RELEASE'  
}    

- add boot jar to create launch script  
  bootJar {  
         launchScript()  
  }  
- `gradle clean build -i`





